from django.test import TestCase
from .models import Company, Employee
from django.contrib.auth.models import User

class CompanyModelTest(TestCase):
    def setUp(self):
        Company.objects.create(
            name="Test Corp",
            registration_date="2020-01-01",
            registration_number="123456",
            address="123 Test Ave",
            contact_person="John Doe",
            contact_phone="1234567890",
            email="test@corp.com",
            departments="HR, IT, Sales",
            num_employees=50
        )

    def test_company_str(self):
        company = Company.objects.get(name="Test Corp")
        self.assertEqual(str(company), "Test Corp")
