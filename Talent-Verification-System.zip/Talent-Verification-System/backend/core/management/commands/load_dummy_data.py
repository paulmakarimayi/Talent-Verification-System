from django.core.management.base import BaseCommand
from core.models import Company, Employee
from datetime import date

class Command(BaseCommand):
    help = 'Load dummy company and employee data'

    def handle(self, *args, **kwargs):
        company, created = Company.objects.get_or_create(
            name="AlphaTech",
            registration_date=date(2015, 5, 1),
            registration_number="AT123456",
            address="123 Silicon Road",
            contact_person="Alice Tech",
            contact_phone="555-1234",
            email="contact@alphatech.com",
            departments="Engineering,HR,Marketing",
            num_employees=120
        )

        Employee.objects.create(
            company=company,
            name="John Developer",
            employee_id="JD123",
            department="Engineering",
            role="Backend Developer",
            date_started=date(2020, 1, 10),
            duties="Develop and maintain backend APIs"
        )

        self.stdout.write(self.style.SUCCESS('Dummy data loaded.'))
