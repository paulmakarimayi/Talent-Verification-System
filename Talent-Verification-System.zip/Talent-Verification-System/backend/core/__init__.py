# Core app initializer
