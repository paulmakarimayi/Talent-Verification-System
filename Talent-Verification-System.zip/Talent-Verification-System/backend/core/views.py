from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .models import Company, Employee, RoleAssignment
from .serializers import CompanySerializer, EmployeeSerializer, UserRegisterSerializer
from .permissions import IsAdminOrReadOnly
from django.contrib.auth.models import User
from rest_framework.views import APIView
from rest_framework.authtoken.models import Token

class CompanyListCreateView(generics.ListCreateAPIView):
    queryset = Company.objects.all()
    serializer_class = CompanySerializer
    permission_classes = [IsAuthenticated]

class EmployeeListCreateView(generics.ListCreateAPIView):
    queryset = Employee.objects.all()
    serializer_class = EmployeeSerializer
    permission_classes = [IsAuthenticated]

class BulkEmployeeUpload(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        uploaded_file = request.FILES['file']
        import csv
        import io
        decoded_file = uploaded_file.read().decode('utf-8')
        reader = csv.DictReader(io.StringIO(decoded_file))
        created = 0
        for row in reader:
            Employee.objects.create(
                company_id=row['company_id'],
                name=row['name'],
                employee_id=row.get('employee_id'),
                department=row['department'],
                role=row['role'],
                date_started=row['date_started'],
                date_left=row.get('date_left'),
                duties=row['duties']
            )
            created += 1
        return Response({"message": f"{created} employees uploaded."}, status=201)

class RegisterUserView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserRegisterSerializer

class LogoutView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        request.user.auth_token.delete()
        return Response({"message": "Logged out successfully."}, status=status.HTTP_200_OK)
