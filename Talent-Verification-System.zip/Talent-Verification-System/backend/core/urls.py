from django.urls import path
from rest_framework.authtoken.views import obtain_auth_token
from .views import (
    CompanyListCreateView, EmployeeListCreateView,
    BulkEmployeeUpload, RegisterUserView, LogoutView
)

urlpatterns = [
    path('login/', obtain_auth_token),
    path('logout/', LogoutView.as_view()),
    path('register/', RegisterUserView.as_view()),
    path('companies/', CompanyListCreateView.as_view()),
    path('employees/', EmployeeListCreateView.as_view()),
    path('employees/bulk-upload/', BulkEmployeeUpload.as_view()),
]
